import React, { Component } from "react";

export default class Login extends Component {
  render() {
    return (
      <div class="container">
          <div class="row">
              <div class="col-md-offset-5 col-md-3">
                  <div class="form-login">
                    <h4>Welcome back.</h4>
                    <form>
                       <label>
                         <input type="text" id="userName" class="form-control input-sm chat-input" placeholder="username" />
                         <input type="text" id="userPassword" class="form-control input-sm chat-input" placeholder="password" />
                       </label>

                       <div class="wrapper">
                         <span class="group-btn">
                             <a type="submit" class="btn btn-primary btn-md">Login <i class="fa fa-sign-in"></i></a>
                         </span>
                       </div>
                    </form>
                  </div>
              </div>
          </div>
      </div>
    );
  }
}
