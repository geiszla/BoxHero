import React, { Component } from "react";
import { Link } from 'react-router';
import { Button, Nav, Navbar, NavItem, NavDropdown, MenuItem, Glyphicon} from 'react-bootstrap';

export default class Navigation extends Component {
  render() {
    return (
      <Navbar inverse collapseOnSelect>
        <Navbar.Header>
          <Navbar.Brand>
            <a href="#">Box Hero</a>
          </Navbar.Brand>
          <Navbar.Toggle />
        </Navbar.Header>

        <Navbar.Collapse>
          <Nav>
            <NavItem><Link to="home">Home</Link></NavItem>
            <NavItem><Link to="about">About</Link></NavItem>
            <NavItem><Link to="rules">Rules</Link></NavItem>
          </Nav>
          <Nav pullRight>
            <NavItem><Link to="login"><Glyphicon glyph="log-in"/> Login</Link></NavItem>
            <NavItem><Link to="register"><Glyphicon glyph="new-window" /> Register </Link></NavItem>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
    );
  }
}
