import React, { Component } from "react";

export default class Register extends Component {
  render() {
    return (
      <div class="container">
          <div class="row">
              <div class="col-md-offset-5 col-md-3">
                  <div class="form-login">
                    <h4>Register for BoxHero.</h4>
                    <form>
                       <label>
                         <input type="text" id="userName" class="form-control input-sm chat-input" placeholder="username" />
                         <input type="text" id="userEmail" class="form-control input-sm chat-input" placeholder="email" />
                         <input type="text" id="userName" class="form-control input-sm chat-input" placeholder="password" />
                       </label>

                       <div class="wrapper">
                         <span class="group-btn">
                             <a type="submit" class="btn btn-primary btn-md">Login <i class="fa fa-sign-in"></i></a>
                         </span>
                       </div>
                    </form>
                  </div>
              </div>
          </div>
      </div>
    );
  }
}
