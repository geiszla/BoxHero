import App from './components/app';
import React from 'react';
import { Route, IndexRoute } from 'react-router';
import Home from './components/home';
import About from './components/about';
import Rules from './components/rules'
import Login from './components/login';
import Register from './components/register';

export default (
  <Route path='/' component={App}>
    <IndexRoute component={Home} />
    <Route path='home' component={Home} />
    <Route path='about' component={About} />
    <Route path='rules' component={Rules} />
    <Route path='login' component={Login} />
    <Route path='register' component={Register} />
  </Route>
);
